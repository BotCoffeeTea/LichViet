package com.vanpt.lunarcalendar.interfaces;

import com.vanpt.lunarcalendar.models.EventObject;

/**
 * Created by vanpt on 12/8/2016.
 */

public interface OnItemClickListener {
    void onItemClick(EventObject item);
}
