package com.vanpt.lunarcalendar.utils;

/**
 * Created by vanpt on 11/23/2016.
 */

public final class Constants {

    public final static String[] DAYS = new String[]{"",
            "Chủ Nhật",
            "Thứ Hai",
            "Thứ Ba",
            "Thứ Tư",
            "Thứ Năm",
            "Thứ Sáu",
            "Thứ Bảy"};
}
