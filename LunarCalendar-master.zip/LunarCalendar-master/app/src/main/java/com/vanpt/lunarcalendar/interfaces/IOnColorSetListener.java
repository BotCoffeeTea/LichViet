package com.vanpt.lunarcalendar.interfaces;

/**
 * Created by vanpt on 8/16/2017.
 */

public interface IOnColorSetListener {
    void onColorSet(int color);
}
